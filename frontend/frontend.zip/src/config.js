// Placeholder config for backend API
const config = {
  API_BASE_URL: 'http://localhost:5000',
};

export const API_BASE_URL = 'http://localhost:5000';

export default config;
