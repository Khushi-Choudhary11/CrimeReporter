import React from 'react';

const AllAuthorities = () => (
  <div>
    <h1>All Authorities</h1>
    <p>List of all authorities in the system.</p>
  </div>
);

export default AllAuthorities;