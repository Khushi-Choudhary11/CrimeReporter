import React from 'react';

const AllUsers = () => (
  <div>
    <h1>All Users</h1>
    <p>List of all users in the system.</p>
  </div>
);

export default AllUsers;