import React from 'react';

const CrimeAnalysis = () => (
  <div>
    <h1>Crime Analysis</h1>
    <p>Analyze crime data and trends here.</p>
  </div>
);

export default CrimeAnalysis;